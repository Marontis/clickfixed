// ============================================================
// Click Fixed — Background Service Worker (MV3)
//
// Two-agent architecture:
//   SENSOR AGENT  (this file) — Gemini Nano edge AI + ADK Agent Cloud Fallback
//   THREAT AGENT  (ADK)       — Web Risk + security.txt + A2A workflow
//
// API keys are completely removed from the extension.
// All heavy lifting and API key requirements are delegated to the Cloud Agent.
// ============================================================

const DEFAULT_AGENT_URL = 'https://clickfixed-threat-agent-942275150158.us-central1.run.app';

// ── Init ─────────────────────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  chrome.storage.local.set({
    detections:   [],
    totalBlocked: 0,
    aiMode:       'Detecting...',
    signatures:   [] // Initial signature cache
  });
  console.log('[ClickFixed] 🛡️ Extension installed.');
  
  // Setup alarms for periodic threat signature synchronization (every 60 mins)
  chrome.alarms.create('signature_sync', { periodInMinutes: 60 });
  await syncSignatures();
});

chrome.runtime.onStartup.addListener(async () => {
  await syncSignatures();
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === 'signature_sync') {
    await syncSignatures();
  }
});

// ── Message Passing ──────────────────────────────────────────
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === 'REPORT_THREAT') {
    handleThreatDetected(sender.tab, request.payload);
    handleA2AHandoff(request.payload);
    sendResponse({ received: true });
  } else if (request.type === 'UPDATE_AI_MODE') {
    chrome.storage.local.set({ aiMode: request.mode });
    sendResponse({ success: true });
  } else if (request.type === 'ANALYZE_PAYLOAD') {
    handleAnalyzePayload(request.payload, sendResponse);
    return true; // Keep channel open for async response
  }
  return true;
});

// ── Badge & Storage Update ────────────────────────────────────
async function handleThreatDetected(tab, detection) {
  if (tab?.id) {
    chrome.action.setBadgeText({ text: '!', tabId: tab.id });
    chrome.action.setBadgeBackgroundColor({ color: '#dc2626', tabId: tab.id });
    chrome.action.setBadgeTextColor({ color: '#ffffff', tabId: tab.id });
  }

  const { totalBlocked = 0, detections = [] } = await chrome.storage.local.get(['totalBlocked', 'detections']);
  const updated = detection ? [detection, ...detections].slice(0, 50) : detections;
  await chrome.storage.local.set({
    totalBlocked: totalBlocked + 1,
    detections:   updated
  });
}

// ── Cloud AI Fallback ─────────────────────────────────────────
async function handleAnalyzePayload(payload, sendResponse) {
  const baseUrl = DEFAULT_AGENT_URL.replace(/\/$/, '');
  try {
    const response = await fetch(`${baseUrl}/analyze`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ payload }),
      signal:  AbortSignal.timeout(10_000)
    });

    if (response.ok) {
      const result = await response.json();
      sendResponse({
        malicious: Boolean(result.malicious),
        reason:    String(result.reason || 'Analyzed by Cloud Agent')
      });
    } else {
      console.info(`[ClickFixed] Cloud Threat Agent returned HTTP ${response.status}`);
      sendResponse({ malicious: false, reason: 'Cloud Agent returned error status.' });
    }
  } catch (err) {
    console.info('[ClickFixed] Cloud Threat Agent analyze failed:', err.message);
    sendResponse({ malicious: false, reason: 'Could not contact Cloud Agent.' });
  }
}

// ── Signature Syncing ─────────────────────────────────────────
async function syncSignatures() {
  const baseUrl = DEFAULT_AGENT_URL.replace(/\/$/, '');
  try {
    const response = await fetch(`${baseUrl}/signatures`, {
      signal: AbortSignal.timeout(5_000)
    });
    if (response.ok) {
      const data = await response.json();
      if (data && Array.isArray(data.signatures)) {
        await chrome.storage.local.set({ signatures: data.signatures });
        console.log(`[ClickFixed] ✅ Synced ${data.signatures.length} threat signature patterns from agent.`);
      }
    } else {
      console.info(`[ClickFixed] Agent signatures returned HTTP ${response.status}`);
    }
  } catch (err) {
    console.info('[ClickFixed] Signature sync failed:', err.message);
  }
}

/** Forward proactive threat detections to the ADK A2A workflow backend. */
async function handleA2AHandoff(data) {
  const baseUrl = DEFAULT_AGENT_URL.replace(/\/$/, '');
  try {
    console.log(`[ClickFixed] Handoff telemetry to ADK Workflow backend: ${baseUrl}/a2a/handoff`);
    const response = await fetch(`${baseUrl}/a2a/handoff`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify(data),
      signal:  AbortSignal.timeout(10_000)
    });
    if (response.ok) {
      console.log('[ClickFixed] ✅ Telemetry handoff succeeded.');
    } else {
      console.info(`[ClickFixed] ADK Workflow handoff HTTP error: ${response.status}`);
    }
  } catch (err) {
    console.info('[ClickFixed] ADK Workflow handoff network error:', err.message);
  }
}
